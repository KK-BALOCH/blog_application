from django import forms

from app.models import Author, BlogPost
class FormView(forms.ModelForm):
    class Meta:
        model= BlogPost
        fields = (
            '__all__'
        )
class FormViewAuthor(forms.ModelForm):
    class Meta:
        model= Author
        fields = (
            '__all__'
        )