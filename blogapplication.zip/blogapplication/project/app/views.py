from django.shortcuts import render , redirect, get_object_or_404

from app.form import FormView, FormViewAuthor
from app.models import BlogPost

# Create your views here.
def published_blog(request):
    context = BlogPost.objects.all()
    return render(request , 'published_blog.html' , {'blogs':context})

# detailed page for every blog
def published_blog_detail(request , id):
    data =BlogPost.objects.get(pk = id)
    return render(request , 'published_blog_detail.html' , {'blogs':data})


#detail individual blog of an author missing
def author_all_blog(request , authorname):
    context = BlogPost.objects.filter(author__name = authorname)
    data ={'allBlogs':context}
    print(data)
    return render(request , 'author_all_blog.html' ,{'allBlogs':context})


def form_blog_post(request):
    context ={}
    data = FormView(request.POST or None)
    if data.is_valid():
        data.save()
        return redirect('/')
    context['form'] = data
    return render(request , 'for_blog_post.html' , context)

def form_for_author(request):
    context ={}
    data = FormViewAuthor(request.POST or None)
    if data.is_valid():
        data.save()
        return redirect('/')
    context['form'] = data
    return render(request , 'for_blog_post.html' , context)
def delete(request , id):
    dataDelete = get_object_or_404( BlogPost, id = id)
    dataDelete.delete()
    return redirect('/')